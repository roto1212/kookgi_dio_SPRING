package com.koreait.service;

import org.springframework.ui.Model;

import com.koreait.vo.MvcboardVO;

public interface MvcboardService {
	//text_MvcboardVO
//	public abstract void execute(MvcboardVO mvcboardVO);

	public abstract void execute(Model model);
}
