package test;

public class Test {

	//Test 클래스의 핵심 기능
	public void test() {
		System.out.println("Test 클래스의 핵심기능");
	}
}
